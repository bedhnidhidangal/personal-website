Videos and their poster images
